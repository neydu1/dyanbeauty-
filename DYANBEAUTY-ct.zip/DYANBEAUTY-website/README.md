# DYANBEAUTY website

Your full website with its own server: bookings, loyalty cards with barcodes and QR codes, the admin portal, and emails from your Gmail (new-booking alerts, confirmations, reminders and scheduled campaigns).

It runs on plain Node.js. There is nothing to install apart from Node itself.

## What's in the folder

| File | What it is |
|---|---|
| `public/index.html` | The website clients see |
| `server.js` | The server: stores data, protects the admin, sends email |
| `.env` | Your private settings: admin password and Gmail. Never share or upload this file publicly. |
| `data/` | Created on first start. Holds all bookings, members, points and photos, plus 14 days of daily backups. |

## 1. Connect your Gmail (5 minutes)

Gmail needs an **app password**, a special 16-letter password just for this website. Your normal Gmail password will not work.

1. Go to <https://myaccount.google.com/security> and turn on **2-Step Verification** if it is off.
2. Go to <https://myaccount.google.com/apppasswords>.
3. Type the name `DYANBEAUTY website` and click **Create**.
4. Copy the 16 letters Google shows you.
5. Open `.env` in a text editor and paste them after `GMAIL_APP_PASSWORD=` (spaces don't matter).

`GMAIL_USER` is the Gmail that sends the emails. `OWNER_EMAIL` is where new-booking alerts go. Both are set to cndukwe19@gmail.com.

## 2. Try it on your computer

1. Install **Node.js 20 LTS** from <https://nodejs.org>.
2. Open a terminal in this folder and run:

   ```
   npm start
   ```

3. Open <http://localhost:3000>.
4. Scroll to the footer, click **Staff admin** and sign in with the admin password from `.env`.
5. In **Mail & reminders**, click **Send me a test email** to check Gmail works.

## 3. Put it online

You need a host that keeps the server running all the time and keeps the `data` folder between restarts. Free plans that "sleep" or wipe files will lose bookings and miss reminders.

**Render.com (simple, about $7–8 a month):**

1. Put this folder in a **private** GitHub repository. The `.gitignore` already keeps `.env` and `data/` out of it.
2. On Render: **New → Web Service**, connect the repository.
3. Start command: `node server.js`. Leave the build command empty.
4. Choose a paid instance (not Free), then under **Disks** add a disk mounted at `/var/data` (1 GB is plenty).
5. Under **Environment**, add the settings from your `.env`, plus:
   - `DATA_DIR=/var/data`
   - `SECURE_COOKIES=1`
   - `SITE_URL=https://your-domain.com`
6. Under **Settings → Custom Domains**, add your domain and follow the DNS steps.

**Any VPS or server with Docker:** `docker build -t dyanbeauty .` then `docker run -d -p 80:3000 --env-file .env -v dyan-data:/data dyanbeauty`. Put it behind HTTPS, for example with Caddy or Cloudflare.

## Using the admin

- **Password:** set by `ADMIN_PASSWORD` in `.env`. To change it, edit the file and restart the server. A sign-in lasts 30 days on that device, and **Sign out** ends it. After 10 wrong tries from one connection, sign-in pauses for 15 minutes.
- **Prices** are in naira (₦). Edit them in **Services & prices**.
- **Mail & reminders:**
  - **Write an email:** to upcoming, today's or tomorrow's appointments, everyone who has booked, loyalty members, newsletter subscribers or specific addresses. Personal details fill in automatically: `{first} {name} {date} {time} {services} {ref} {points} {card} {code}`.
  - **Send now, schedule, or repeat** every day, week or month. For example, "every Monday, remind the next 7 days of bookings".
  - **Automatic emails:**
    - a new-booking alert to you
    - a "booking received" email to the client
    - emails when you confirm, cancel or complete a booking
    - reminders 2 days, 1 day, 12, 2 or 1 hours before confirmed appointments
  - **Sent emails** lists every email and whether it went out.
- **Bank transfer:** add your bank name, 10-digit account number, account name and deposit (for example 50%) in **Settings**.
  - **For clients:** after booking, they see your details with copy buttons. They tap "I've sent the transfer", or choose to pay at the studio, and can attach a receipt screenshot.
  - **For you:** you get an email for each reported transfer. Check your bank app, then tap **Mark paid** on the booking. The client is emailed that payment was received.
  - **Without bank details:** clients are told to pay at the studio.
- **After booking:** clients can create a loyalty card or log in, which saves the booking to their profile. Then they see an "Order sent" confirmation. The bell (Alerts) tells them when you confirm, cancel, complete or mark a booking paid.
- **Client PINs:**
  - **Clients:** change their PIN under **Change PIN** on their profile. "Forgot your PIN?" on the login page emails them a 6-digit code that works for 15 minutes.
  - **You:** in **Loyalty clients**, tap **Reset PIN** to create a new PIN (random, or one you type). You can email it, copy it, or send it on WhatsApp. The client is asked to choose their own PIN after logging in.
  - **Emails:** clients get a welcome email with their card number when they sign up, and an email whenever their PIN changes.
- **Client details:** clients can edit their name, phone and birthday on their profile, and get an email confirming the change. To change their email, they enter their PIN, then a 6-digit code sent to the new address. Their old address is told about the change.
- **Front desk:** staff phones must be signed in to the admin for the QR code on a client's card to open their profile.
- **Backups:** the server keeps a daily copy of everything in `data/backups` for 14 days. You can also download everything from **Import & export**.

## Good to know

- Gmail allows about 500 emails a day from one account.
- If you open `public/index.html` straight from your computer without the server, it runs in preview mode and saves only in that browser.
- Search engines can find the site once it is live at your own domain. `SITE_URL` also turns on a sitemap at `/sitemap.xml` for Google Search Console.
