'use strict';
/*
 * DYANBEAUTY website server.
 * Plain Node.js (18+), no npm packages needed.
 * - Serves the site from ./public and uploaded photos from DATA_DIR/uploads
 * - Stores bookings, loyalty members, points, subscribers and settings in DATA_DIR/db.json
 * - Protects the admin with ADMIN_PASSWORD
 * - Sends email through Gmail (new-booking alerts, confirmations, reminders, campaigns)
 */
const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const tls = require('tls');
const os = require('os');

const ROOT = __dirname;

/* ---------- settings from .env ---------- */
(function loadEnv() {
  try {
    for (const line of fs.readFileSync(path.join(ROOT, '.env'), 'utf8').split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/);
      if (!m || process.env[m[1]] !== undefined) continue;
      let v = m[2];
      if (/^".*"$|^'.*'$/.test(v)) v = v.slice(1, -1);
      process.env[m[1]] = v;
    }
  } catch (e) { /* no .env file: rely on real environment variables */ }
})();
process.env.TZ = process.env.TZ || 'Africa/Lagos';

const CFG = {
  port: Number(process.env.PORT) || 3000,
  adminPassword: process.env.ADMIN_PASSWORD || '',
  gmailUser: (process.env.GMAIL_USER || '').trim(),
  gmailPass: (process.env.GMAIL_APP_PASSWORD || '').replace(/\s+/g, ''),
  ownerEmail: (process.env.OWNER_EMAIL || process.env.GMAIL_USER || '').trim(),
  siteUrl: (process.env.SITE_URL || '').replace(/\/+$/, ''),
  smtpHost: process.env.SMTP_HOST || 'smtp.gmail.com',
  smtpPort: Number(process.env.SMTP_PORT) || 465,
  dataDir: path.resolve(ROOT, process.env.DATA_DIR || 'data'),
  secureCookies: process.env.SECURE_COOKIES === '1',
};
const mailReady = () => !!(CFG.gmailUser && CFG.gmailPass);

/* ---------- data store: one JSON file, written atomically ---------- */
const UPLOADS = path.join(CFG.dataDir, 'uploads');
const BACKUPS = path.join(CFG.dataDir, 'backups');
const RECEIPTS = path.join(CFG.dataDir, 'receipts');
fs.mkdirSync(UPLOADS, { recursive: true });
fs.mkdirSync(RECEIPTS, { recursive: true });
fs.mkdirSync(BACKUPS, { recursive: true });
const DB_FILE = path.join(CFG.dataDir, 'db.json');
let DB = { docs: {}, sessions: {}, resets: {}, emailChanges: {} };
try {
  DB = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
  DB.docs = DB.docs || {};
  DB.sessions = DB.sessions || {};
  DB.resets = DB.resets || {};
  DB.emailChanges = DB.emailChanges || {};
} catch (e) { /* first run */ }

let saveTimer = null;
function persist() { clearTimeout(saveTimer); saveTimer = setTimeout(flush, 150); }
function flush() {
  clearTimeout(saveTimer);
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(DB));
  fs.renameSync(tmp, DB_FILE);
}
const clone = (v) => (v == null ? v : JSON.parse(JSON.stringify(v)));
function dget(col, id) { const c = DB.docs[col]; return c && c[id] ? clone(c[id]) : null; }
function dset(col, id, data) { (DB.docs[col] || (DB.docs[col] = {}))[id] = data; persist(); }
function ddel(col, id) { if (DB.docs[col] && DB.docs[col][id]) { delete DB.docs[col][id]; persist(); } }
function dlist(col) { return Object.entries(DB.docs[col] || {}).map(([id, d]) => ({ _id: id, ...clone(d) })); }

function dailyBackup() {
  try {
    if (!fs.existsSync(DB_FILE)) return;
    const name = path.join(BACKUPS, 'db-' + localDate(new Date()) + '.json');
    if (!fs.existsSync(name)) fs.copyFileSync(DB_FILE, name);
    const files = fs.readdirSync(BACKUPS).filter((f) => /^db-\d{4}-\d\d-\d\d\.json$/.test(f)).sort();
    while (files.length > 14) fs.unlinkSync(path.join(BACKUPS, files.shift()));
  } catch (e) { console.error('Backup failed:', e.message); }
}

/* ---------- small helpers ---------- */
const SEG = /^[A-Za-z0-9_\-.~:@+]{1,200}$/;
const EMAIL = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[^\s@<>"',;]+$/;
const pad = (n) => String(n).padStart(2, '0');
function localDate(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function fmtHour(h) { h = Number(h); const ap = h >= 12 ? 'PM' : 'AM'; return `${h % 12 || 12}:00 ${ap}`; }
function fmtDate(s) {
  try { return new Date(s + 'T12:00:00').toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }); }
  catch (e) { return s; }
}
function naira(n) { return '₦' + Math.round(Number(n) || 0).toLocaleString('en-NG'); }
const clip = (v, n = 500) => String(v == null ? '' : v).slice(0, n);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const rid = (n = 18) => crypto.randomBytes(n).toString('base64url');
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/* ---------- admin password and sessions ---------- */
const PW_SALT = crypto.randomBytes(16);
const ADMIN_HASH = CFG.adminPassword ? crypto.scryptSync(CFG.adminPassword, PW_SALT, 32) : null;
function passwordOk(pw) {
  if (!ADMIN_HASH || typeof pw !== 'string' || pw.length > 200) return false;
  return crypto.timingSafeEqual(crypto.scryptSync(pw, PW_SALT, 32), ADMIN_HASH);
}
const SESSION_DAYS = 30;
function newAdminSession() {
  const token = rid(32);
  DB.sessions[sha256(token)] = { exp: Date.now() + SESSION_DAYS * 864e5 };
  persist();
  return token;
}
function isAdminToken(token) {
  if (!token) return false;
  const s = DB.sessions[sha256(token)];
  if (!s) return false;
  if (s.exp < Date.now()) { delete DB.sessions[sha256(token)]; persist(); return false; }
  return true;
}

/* login attempt limits per IP */
const attempts = new Map();
function limited(ip, kind) {
  const k = kind + ':' + ip;
  const now = Date.now();
  const a = attempts.get(k) || { n: 0, reset: now + 15 * 60e3 };
  if (now > a.reset) { a.n = 0; a.reset = now + 15 * 60e3; }
  a.n++;
  attempts.set(k, a);
  return a.n > 10;
}

/* ---------- cookies ---------- */
function parseCookies(req) {
  const out = {};
  for (const part of String(req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function isHttps(req) { return CFG.secureCookies || req.socket.encrypted || req.headers['x-forwarded-proto'] === 'https'; }
function setCookie(req, res, name, value, maxAgeSec) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${maxAgeSec}`];
  if (isHttps(req)) parts.push('Secure');
  const prev = res.getHeader('Set-Cookie') || [];
  res.setHeader('Set-Cookie', [...(Array.isArray(prev) ? prev : [prev]), parts.join('; ')]);
}
const VID = /^[A-Za-z0-9_-]{16,64}$/;

/* ---------- HTTP plumbing ---------- */
function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(Object.assign(new Error('too_large'), { status: 413 })); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJSON(req, limit = 1024 * 1024) {
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try { return JSON.parse(buf.toString('utf8')); }
  catch (e) { throw Object.assign(new Error('bad_json'), { status: 400 }); }
}
const SECURITY_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'X-Frame-Options': 'SAMEORIGIN',
  'Content-Security-Policy': [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://cdn.jsdelivr.net",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: blob:",
    "connect-src 'self'",
    "frame-ancestors 'self'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join('; '),
};
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain', '.xml': 'application/xml' };
function serveFile(res, file, cache) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Not found'); return; }
    const type = TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, { ...SECURITY_HEADERS, 'Content-Type': type, 'Content-Length': st.size, 'Cache-Control': cache });
    fs.createReadStream(file).pipe(res);
  });
}

/* ---------- loyalty maths (matches the page) ---------- */
function siteDoc() { return dget('site', 'main') || {}; }
function pointsFor(key) {
  const site = siteDoc();
  const welcome = Number(site.welcome ?? 50);
  const L = dget('ledger', key) || {};
  const e = L.entries || [];
  return {
    balance: welcome + e.reduce((a, x) => a + Number(x.pts || 0), 0),
    visits: L.visits || 0,
  };
}
function memberByEmail(email) {
  if (!email) return null;
  const low = String(email).toLowerCase();
  return dlist('members').find((m) => (m.email || '').toLowerCase() === low) || null;
}

/* ---------- access rules for /api/db ---------- */
const SELF_RW = new Set(['bookings', 'members', 'subs']);
const SELF_READ = new Set(['ledger']);
const PUBLIC_READ = new Set(['site']);
const ADMIN_ONLY = new Set(['campaigns', 'mail', 'maillog']);
const KNOWN = new Set([...SELF_RW, ...SELF_READ, ...PUBLIC_READ, ...ADMIN_ONLY]);

function cleanBookingItem(b) {
  const out = {
    id: clip(b.id, 40), created: clip(b.created, 40), name: clip(b.name, 120), phone: clip(b.phone, 40),
    email: EMAIL.test(String(b.email || '').trim()) ? String(b.email).trim().toLowerCase() : '',
    serviceIds: Array.isArray(b.serviceIds) ? b.serviceIds.slice(0, 20).map((x) => clip(x, 60)) : [],
    services: Array.isArray(b.services) ? b.services.slice(0, 20).map((x) => clip(x, 120)) : [],
    studio: !!b.studio, date: /^\d{4}-\d\d-\d\d$/.test(b.date) ? b.date : '',
    start: Math.min(23, Math.max(0, parseInt(b.start, 10) || 0)), hours: Math.min(16, Math.max(1, parseInt(b.hours, 10) || 1)),
    guests: clip(b.guests, 6), notes: clip(b.notes, 1000), est: Math.max(0, Number(b.est) || 0), member: !!b.member,
  };
  return out;
}

const RECEIPT_NAME = /^[A-Za-z0-9_-]{6,60}\.(jpg|png|webp|gif)$/;
function cleanPay(raw, est) {
  raw = raw && typeof raw === 'object' ? raw : {};
  return {
    method: raw.method === 'studio' ? 'studio' : 'transfer',
    choice: raw.choice === 'deposit' ? 'deposit' : 'full',
    amount: Math.max(0, Math.min(Number(raw.amount) || 0, Number(est) || 0 || Number(raw.amount) || 0)),
    sender: clip(raw.sender, 120), txRef: clip(raw.txRef, 80),
    receipt: RECEIPT_NAME.test(String(raw.receipt || '')) && fs.existsSync(path.join(RECEIPTS, raw.receipt)) ? raw.receipt : '',
  };
}
/* A client may add bookings and report a transfer, but never change status, confirm payment or touch reminders. */
function sanitizeBookingsDoc(vid, incoming, prev) {
  const prevItems = (prev && prev.items) || [];
  const prevById = new Map(prevItems.map((x) => [x.id, x]));
  const seen = new Set();
  const items = [];
  const fresh = [];
  const reported = [];
  for (const raw of (incoming.items || []).slice(0, 60)) {
    if (!raw || typeof raw !== 'object' || !raw.id || seen.has(raw.id)) continue;
    seen.add(raw.id);
    const old = prevById.get(raw.id);
    if (old) {
      const cur = old.pay || { status: 'awaiting' };
      const want = raw.pay && raw.pay.status;
      if ((cur.status === 'awaiting' || cur.status === 'studio') && (want === 'reported' || want === 'studio')) {
        const np = cleanPay(raw.pay, old.est);
        old.pay = want === 'reported'
          ? { ...np, method: 'transfer', status: 'reported', reportedAt: new Date().toISOString() }
          : { ...np, method: 'studio', status: 'studio', amount: Number(old.est) || 0 };
        if (want === 'reported') reported.push(old);
      }
      if (raw.member && !old.member) old.member = true;
      items.push(old);
      continue;
    }
    const b = cleanBookingItem(raw);
    b.status = 'Pending';
    b.pay = { status: 'awaiting', method: 'transfer', amount: 0 };
    if (!b.date) continue;
    items.push(b);
    fresh.push(b);
  }
  for (const old of prevItems) if (!seen.has(old.id)) items.push(old);
  return { doc: { owner: vid, name: clip(incoming.name, 120), phone: clip(incoming.phone, 40), items: items.slice(0, 80) }, fresh, reported };
}

/* Members manage their own profile; card number, email and reward decisions stay locked. */
function sanitizeMemberDoc(vid, incoming, prev) {
  const reqs = Array.isArray(incoming.requests) ? incoming.requests.slice(-50) : [];
  const prevReqs = new Map(((prev && prev.requests) || []).map((r) => [r.id, r]));
  const requests = reqs.filter((r) => r && r.id).map((r) => {
    const old = prevReqs.get(r.id);
    if (old) return old;
    return { id: clip(r.id, 40), rewardId: clip(r.rewardId, 40), name: clip(r.name, 120), pts: Math.max(0, Number(r.pts) || 0), status: 'Requested', at: new Date().toISOString() };
  });
  for (const old of prevReqs.values()) if (!requests.find((r) => r.id === old.id)) requests.push(old);
  const doc = {
    name: clip(incoming.name, 120), phone: clip(incoming.phone, 40),
    birthday: /^\d{4}-\d\d-\d\d$/.test(incoming.birthday || '') ? incoming.birthday : '',
    referredBy: clip(incoming.referredBy, 30), requests,
  };
  if (prev && prev.pinHash) {
    return { ...prev, ...doc, email: prev.email, ref: prev.ref, joined: prev.joined, pinHash: prev.pinHash };
  }
  // sign-up
  const email = String(incoming.email || '').trim().toLowerCase();
  if (!EMAIL.test(email)) throw Object.assign(new Error('bad_email'), { status: 400 });
  if (!/^[a-f0-9]{64}$/.test(String(incoming.pinHash || '')) && !/^x\d+$/.test(String(incoming.pinHash || ''))) throw Object.assign(new Error('bad_pin'), { status: 400 });
  const other = dlist('members').find((m) => m._id !== vid && (m.email || '').toLowerCase() === email);
  let carried = {};
  if (other && other.pinHash) throw Object.assign(new Error('email_taken'), { status: 409 });
  if (other) {
    // An imported customer is claiming their card: keep their card number and history.
    carried = { ref: other.ref, joined: other.joined, phone: other.phone, birthday: other.birthday, altRefs: other.altRefs };
    const Lo = dget('ledger', other._id);
    if (Lo) {
      const Lm = dget('ledger', vid) || { entries: [], visits: 0 };
      dset('ledger', vid, { ...Lm, entries: [...(Lo.entries || []), ...(Lm.entries || [])].slice(-300), visits: (Lo.visits || 0) + (Lm.visits || 0), lastCheckIn: Lm.lastCheckIn || Lo.lastCheckIn || '' });
      ddel('ledger', other._id);
    }
    ddel('members', other._id);
  }
  let ref = String(carried.ref || incoming.ref || '').toUpperCase();
  const taken = (r) => dlist('members').some((m) => m._id !== vid && ((m.ref || '').toUpperCase() === r || (m.altRefs || []).includes(r)));
  if (!/^[A-Z0-9-]{4,24}$/.test(ref) || (!carried.ref && taken(ref))) {
    do { ref = 'DY' + crypto.randomBytes(6).toString('hex').toUpperCase().replace(/[01]/g, 'X').slice(0, 8); } while (taken(ref));
  }
  return {
    ...doc, email, pinHash: incoming.pinHash, ref,
    phone: doc.phone || carried.phone || '', birthday: doc.birthday || carried.birthday || '',
    altRefs: carried.altRefs || [], joined: carried.joined || new Date().toISOString(),
  };
}

function sanitizeSub(incoming) {
  const email = String(incoming.email || '').trim().toLowerCase();
  if (!EMAIL.test(email)) throw Object.assign(new Error('bad_email'), { status: 400 });
  return { name: clip(incoming.name, 120), email, birthday: /^\d{4}-\d\d-\d\d$/.test(incoming.birthday || '') ? incoming.birthday : '', at: new Date().toISOString() };
}

/* ---------- email: a tiny Gmail (SMTP over TLS) sender ---------- */
const b64 = (s) => Buffer.from(String(s), 'utf8').toString('base64');
const encHeader = (s) => '=?UTF-8?B?' + b64(String(s).replace(/[\r\n]+/g, ' ')) + '?=';
const wrap76 = (s) => s.replace(/.{1,76}/g, '$&\r\n');

function buildMessage({ to, subject, text, html, replyTo }) {
  const boundary = 'dyan_' + rid(12);
  const domain = (CFG.gmailUser.split('@')[1] || 'dyanbeauty.local');
  const headers = [
    `From: ${encHeader('DYANBEAUTY')} <${CFG.gmailUser}>`,
    `To: <${to}>`,
    `Subject: ${encHeader(subject)}`,
    `Date: ${new Date().toUTCString().replace('GMT', '+0000')}`,
    `Message-ID: <${rid(16)}@${domain}>`,
    'MIME-Version: 1.0',
    replyTo && EMAIL.test(replyTo) ? `Reply-To: <${replyTo}>` : null,
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
  ].filter(Boolean);
  const body = [
    `--${boundary}`, 'Content-Type: text/plain; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', wrap76(b64(text)),
    `--${boundary}`, 'Content-Type: text/html; charset=UTF-8', 'Content-Transfer-Encoding: base64', '', wrap76(b64(html)),
    `--${boundary}--`, '',
  ];
  return headers.join('\r\n') + '\r\n\r\n' + body.join('\r\n');
}

function smtpSend(msg) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const done = (err) => { if (settled) return; settled = true; err ? reject(err) : resolve(); };
    const sock = tls.connect({ host: CFG.smtpHost, port: CFG.smtpPort, servername: CFG.smtpHost, rejectUnauthorized: process.env.SMTP_INSECURE !== '1' });
    sock.setTimeout(30000, () => sock.destroy(new Error('Gmail did not answer in time')));
    let buf = '';
    let waiter = null;
    const tryResolve = () => {
      if (!waiter) return;
      const lines = buf.split('\r\n');
      for (let i = 0; i < lines.length - 1; i++) {
        if (/^\d{3} /.test(lines[i])) {
          const resp = { code: Number(lines[i].slice(0, 3)), text: lines.slice(0, i + 1).join('\n') };
          buf = lines.slice(i + 1).join('\r\n');
          const w = waiter; waiter = null; w.resolve(resp);
          return;
        }
      }
    };
    sock.on('data', (d) => { buf += d.toString('utf8'); tryResolve(); });
    sock.on('error', (e) => { if (waiter) { const w = waiter; waiter = null; w.reject(e); } done(e); });
    const read = () => new Promise((res, rej) => { waiter = { resolve: res, reject: rej }; tryResolve(); });
    const step = async (cmd, ok) => {
      if (cmd != null) sock.write(cmd + '\r\n');
      const r = await read();
      if (!ok.includes(r.code)) {
        const hint = r.code === 535 ? ' (Gmail rejected the login: check GMAIL_USER and the app password)' : '';
        throw new Error(`Gmail said ${r.code}${hint}: ${r.text.slice(0, 160)}`);
      }
      return r;
    };
    sock.once('secureConnect', async () => {
      try {
        await step(null, [220]);
        await step('EHLO ' + (os.hostname().replace(/[^A-Za-z0-9.-]/g, '') || 'localhost'), [250]);
        await step('AUTH LOGIN', [334]);
        await step(b64(CFG.gmailUser), [334]);
        await step(b64(CFG.gmailPass), [235]);
        await step(`MAIL FROM:<${CFG.gmailUser}>`, [250]);
        await step(`RCPT TO:<${msg.to}>`, [250, 251]);
        await step('DATA', [354]);
        const data = buildMessage(msg).replace(/\r\n\./g, '\r\n..');
        await step(data + '\r\n.', [250]);
        sock.write('QUIT\r\n');
        sock.end();
        done();
      } catch (e) { sock.destroy(); done(e); }
    });
  });
}

/* Branded email layout */
function escHtml(s) { return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function emailHTML(text) {
  const site = siteDoc();
  const paras = escHtml(text).split(/\n{2,}/).map((p) => `<p style="margin:0 0 14px;line-height:1.6">${p.replace(/\n/g, '<br>')}</p>`).join('');
  const book = CFG.siteUrl ? `<p style="margin:22px 0 6px"><a href="${escHtml(CFG.siteUrl)}/#book" style="display:inline-block;background:#e0218a;color:#ffffff;text-decoration:none;font-weight:bold;padding:12px 26px;border-radius:999px">Book with DYANBEAUTY</a></p>` : '';
  const ig = 'https://www.instagram.com/dyanbeauty__/';
  const fb = site.facebook || 'https://www.facebook.com/profile.php?id=100066491832750';
  return `<!doctype html><html><body style="margin:0;background:#fff0f7;padding:24px 12px;font-family:Arial,Helvetica,sans-serif;color:#4a1236">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td align="center">
<table role="presentation" width="100%" style="max-width:560px;background:#ffffff;border-radius:20px;overflow:hidden;border:1px solid #f5bcd9">
<tr><td style="background:linear-gradient(135deg,#ff3fa4,#c9137a);background-color:#e0218a;padding:26px 28px;color:#ffffff;font-family:Georgia,serif;font-size:26px;letter-spacing:4px">DYAN<span style="font-style:italic;letter-spacing:0">beauty</span></td></tr>
<tr><td style="padding:28px 28px 10px;font-size:15px">${paras}${book}</td></tr>
<tr><td style="padding:18px 28px 26px;font-size:12px;color:#8c5b78;border-top:1px solid #ffe6f2">Lashes · Nails · Glam · Bridal · Studio hire<br>
<a href="${ig}" style="color:#c9137a">Instagram</a> · <a href="${escHtml(fb)}" style="color:#c9137a">Facebook</a>${CFG.ownerEmail ? ` · <a href="mailto:${escHtml(CFG.ownerEmail)}" style="color:#c9137a">${escHtml(CFG.ownerEmail)}</a>` : ''}</td></tr>
</table></td></tr></table></body></html>`;
}

/* One email at a time, with a log the admin can read. */
let mailChain = Promise.resolve();
function logMail(entry) {
  const L = dget('maillog', 'recent') || { items: [] };
  L.items = [entry, ...(L.items || [])].slice(0, 400);
  dset('maillog', 'recent', L);
}
function queueMail({ to, subject, text, kind, replyTo }) {
  const job = mailChain.then(async () => {
    const entry = { at: new Date().toISOString(), to, subject: clip(subject, 200), kind: kind || 'mail', ok: false, error: '' };
    if (!EMAIL.test(String(to || ''))) { entry.error = 'Invalid email address'; logMail(entry); return false; }
    if (!mailReady()) { entry.error = 'Gmail is not set up on the server yet'; logMail(entry); return false; }
    try {
      await smtpSend({ to, subject: String(subject).replace(/[\r\n]+/g, ' '), text, html: emailHTML(text), replyTo });
      entry.ok = true;
    } catch (e) { entry.error = clip(e.message, 300); }
    logMail(entry);
    await sleep(350);
    return entry.ok;
  });
  mailChain = job.catch(() => false);
  return job;
}

/* ---------- mail settings, templates and audiences ---------- */
const MAIL_DEFAULTS = {
  notifyOwner: true, confirmClient: true, statusEmails: true, welcomeEmail: true,
  remindOn: true, remindHours: [24, 2], remindPending: false,
  reminderSubject: 'Reminder: your DYANBEAUTY appointment on {date}',
  reminderBody: 'Hi {first},\n\nThis is a sweet reminder of your appointment at DYANBEAUTY.\n\nServices: {services}\nDate: {date}\nTime: {time}\nBooking ref: {ref}\n\nPlease arrive 10 minutes early so we can start on time. Need to reschedule? Just reply to this email.\n\nSee you soon, princess!\nDYANBEAUTY',
};
function mailSettings() { return { ...MAIL_DEFAULTS, ...(dget('mail', 'settings') || {}) }; }
function fill(tpl, vars) { return String(tpl || '').replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null ? String(vars[k]) : '')); }
function varsFor({ name, email, booking }) {
  const site = siteDoc();
  const m = memberByEmail(email);
  const v = {
    name: name || (m && m.name) || 'there', email: email || '',
    studio: 'DYANBEAUTY', code: site.promo || 'PRINCESS15', phone: site.phone || '',
    card: m ? m.ref : '', points: m ? pointsFor(m._id).balance.toLocaleString('en-NG') : '',
    date: '', time: '', services: '', ref: '', estimate: '',
  };
  v.first = String(v.name).trim().split(/\s+/)[0] || 'there';
  if (booking) {
    v.date = fmtDate(booking.date);
    v.time = `${fmtHour(booking.start)} – ${fmtHour(Number(booking.start) + Number(booking.hours || 1))}`;
    v.services = (booking.services || []).join(', ') + (booking.studio ? ((booking.services || []).length ? ' + ' : '') + `studio hire (${booking.hours}h)` : '');
    v.ref = booking.id || '';
    v.estimate = naira(booking.est);
  }
  return v;
}
function allBookings() { return dlist('bookings').flatMap((d) => (d.items || []).map((b) => ({ ...b, _key: d._id }))); }
function apptTime(b) { return new Date(`${b.date}T${pad(b.start)}:00:00`).getTime(); }

function resolveAudience(a) {
  a = a || {};
  const type = a.type || 'upcoming';
  const today = localDate(new Date());
  const tomorrow = localDate(new Date(Date.now() + 864e5));
  const out = new Map();
  const add = (email, item) => { email = String(email || '').trim().toLowerCase(); if (EMAIL.test(email) && !out.has(email)) out.set(email, { email, ...item }); };
  if (['upcoming', 'today', 'tomorrow', 'all_bookings'].includes(type)) {
    const days = Math.min(90, Math.max(1, parseInt(a.days, 10) || 7));
    const until = localDate(new Date(Date.now() + days * 864e5));
    allBookings()
      .filter((b) => {
        if (type === 'all_bookings') return true;
        if (b.status === 'Cancelled' || b.status === 'Completed') return false;
        if (type === 'today') return b.date === today;
        if (type === 'tomorrow') return b.date === tomorrow;
        return b.date >= today && b.date <= until;
      })
      .sort((x, y) => apptTime(x) - apptTime(y))
      .forEach((b) => add(b.email, { name: b.name, booking: b }));
  } else if (type === 'members') {
    dlist('members').forEach((m) => add(m.email, { name: m.name }));
  } else if (type === 'subscribers') {
    dlist('subs').forEach((s) => add(s.email, { name: s.name }));
  } else if (type === 'custom') {
    String(a.emails || '').split(/[\s,;]+/).forEach((e) => { const m = memberByEmail(e); add(e, { name: m ? m.name : '' }); });
  }
  return [...out.values()];
}

/* ---------- member accounts: welcome, PIN changes ---------- */
function carryGuestBookings(fromVid, memberId) {
  if (!fromVid || fromVid === memberId) return;
  const guest = dget('bookings', fromVid);
  if (!guest || !(guest.items || []).length) return;
  const mem = dget('members', memberId) || {};
  const mine = dget('bookings', memberId) || { owner: memberId, name: mem.name, phone: mem.phone, items: [] };
  const ids = new Set((mine.items || []).map((x) => x.id));
  mine.items = [...guest.items.filter((x) => !ids.has(x.id)).map((x) => ({ ...x, member: true })), ...(mine.items || [])].slice(0, 80);
  dset('bookings', memberId, mine);
  ddel('bookings', fromVid);
}
function onSignup(m) {
  if (!mailSettings().welcomeEmail || !m.email) return;
  const v = varsFor({ name: m.name, email: m.email });
  queueMail({ to: m.email, kind: 'welcome', subject: 'Welcome to the DYAN Loyalty Club, ' + v.first + '!',
    text: fill(`Hi {first},\n\nYour DYANBEAUTY loyalty card is ready and you're signed in.\n\nCard number: ${m.ref}\nWelcome points: ${Number(siteDoc().welcome ?? 50)}\n\nShow the barcode or QR code on your card at the front desk to check in and collect points on every visit.\n\nYou log in with this email address and the PIN you chose. If you ever forget your PIN, tap "Forgot your PIN?" on the login page.\n\nWith love,\nDYANBEAUTY`, v) });
}
function detailsEmail(prev, next) {
  if (!next.email) return;
  const changed = [];
  if ((prev.name || '') !== (next.name || '')) changed.push(`Name: ${next.name || '—'}`);
  if ((prev.phone || '') !== (next.phone || '')) changed.push(`Phone: ${next.phone || '—'}`);
  if ((prev.birthday || '') !== (next.birthday || '')) changed.push(`Birthday: ${next.birthday ? fmtDate(next.birthday) : '—'}`);
  if (!changed.length) return;
  const v = varsFor({ name: next.name, email: next.email });
  queueMail({ to: next.email, kind: 'details-updated', subject: 'Your DYANBEAUTY details were updated',
    text: fill('Hi {first},\n\nThe details on your DYANBEAUTY loyalty card were just updated:\n\n' + changed.join('\n') + '\n\nIf you didn\'t make this change, reply to this email or call the studio straight away.\n\nDYANBEAUTY', v) });
}
function pinEmail(m, how, tempPin) {
  if (!m.email) return;
  const v = varsFor({ name: m.name, email: m.email });
  const text = tempPin
    ? `Hi {first},\n\nThe studio has reset the PIN for your DYANBEAUTY loyalty card.\n\nYour new PIN: ${tempPin}\n\nLog in with your email and this PIN. You'll be asked to choose your own PIN straight away.\n\nDYANBEAUTY`
    : `Hi {first},\n\nThe PIN for your DYANBEAUTY loyalty card was ${how} just now.\n\nIf this wasn't you, reply to this email or call the studio and we'll secure your card.\n\nDYANBEAUTY`;
  queueMail({ to: m.email, kind: 'pin-' + (tempPin ? 'reset-by-studio' : how.replace(/\s+/g, '-')), subject: tempPin ? 'Your new DYANBEAUTY PIN' : 'Your DYANBEAUTY PIN was ' + how, text: fill(text, v) });
}
const HEX64 = /^[a-f0-9]{64}$/;
const PIN_HASH = (h) => HEX64.test(String(h || '')) || /^x\d+$/.test(String(h || ''));
function sameHash(a, b) { return typeof a === 'string' && typeof b === 'string' && a.length === b.length && crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b)); }

/* ---------- automatic emails ---------- */
function bankText(b) {
  const site = siteDoc();
  const k = site.bank || {};
  if (!k.acctNo || !k.name) return '';
  const pct = Math.min(100, Math.max(0, Number(site.depositPct) || 0));
  const dep = pct > 0 && pct < 100 ? Math.round((Number(b.est) || 0) * pct / 100) : 0;
  return ['', '', 'Pay by bank transfer:', `Bank: ${k.name}`, `Account name: ${k.acctName || 'DYANBEAUTY'}`, `Account number: ${k.acctNo}`,
    dep ? `Deposit to secure your spot: ${naira(dep)} (full amount ${naira(b.est)})` : `Amount: ${naira(b.est)}`,
    `Use ${b.id} as the transfer description.`].join('\n');
}
function payLabel(p) {
  p = p || {};
  return p.status === 'confirmed' ? 'Paid' : p.status === 'reported' ? 'Transfer reported, waiting for the studio to check' : p.status === 'studio' ? 'Paying at the studio' : 'Not paid yet';
}
function onPaymentReported(list) {
  if (!mailSettings().notifyOwner || !CFG.ownerEmail) return;
  for (const b of list) {
    const p = b.pay || {};
    queueMail({ to: CFG.ownerEmail, kind: 'payment-reported', replyTo: b.email,
      subject: `Transfer reported: ${b.name} · ${naira(p.amount)} · ${b.id}`,
      text: [`${b.name} says they have paid by bank transfer.`, '', `Booking: ${b.id}`, `Amount: ${naira(p.amount)} (${p.choice === 'deposit' ? 'deposit' : 'full payment'})`,
        `Name on transfer: ${p.sender || '—'}`, `Transfer reference: ${p.txRef || '—'}`, `Receipt: ${p.receipt ? 'uploaded, open it in the admin portal' : 'none'}`, '',
        'Check your bank app, then tap "Mark paid" on the booking in your admin portal.'].join('\n') });
  }
}
function onNewBookings(fresh) {
  const s = mailSettings();
  for (const b of fresh) {
    const v = varsFor({ name: b.name, email: b.email, booking: b });
    if (s.notifyOwner && CFG.ownerEmail) {
      const lines = [
        `New booking request ${b.id}`, '',
        `Name: ${b.name}`, `Phone / WhatsApp: ${b.phone}`, `Email: ${b.email || '—'}`,
        `Services: ${v.services || '—'}`, `Date: ${v.date}`, `Time: ${v.time}`, `Guests: ${b.guests || 1}`,
        `Estimated total: ${v.estimate}`, `Loyalty member: ${b.member ? 'Yes' : 'No'}`, `Notes: ${b.notes || '—'}`, '',
        'Confirm it in your admin portal so the time is blocked on the booking form.',
      ];
      queueMail({ to: CFG.ownerEmail, subject: `New booking: ${b.name} · ${v.date} ${fmtHour(b.start)}`, text: lines.join('\n'), kind: 'owner-alert', replyTo: b.email });
    }
    if (s.confirmClient && b.email) {
      queueMail({ to: b.email, kind: 'booking-received', subject: `We received your DYANBEAUTY booking (${b.id})`,
        text: fill('Hi {first},\n\nThank you for booking with DYANBEAUTY! We have received your request and will confirm it shortly.\n\nServices: {services}\nDate: {date}\nTime: {time}\nEstimated total: {estimate}\nBooking ref: {ref}', v) + bankText(b) + '\n\nWith love,\nDYANBEAUTY' });
    }
  }
}
function onStatusChanges(prev, next) {
  const s = mailSettings();
  if (!s.statusEmails) return;
  const before = new Map(((prev && prev.items) || []).map((x) => [x.id, x.status]));
  const payBefore = new Map(((prev && prev.items) || []).map((x) => [x.id, (x.pay || {}).status]));
  for (const b of (next.items || [])) {
    if (b.email && (b.pay || {}).status === 'confirmed' && payBefore.has(b.id) && payBefore.get(b.id) !== 'confirmed') {
      const pv = varsFor({ name: b.name, email: b.email, booking: b });
      queueMail({ to: b.email, kind: 'payment-confirmed', subject: `Payment received for your DYANBEAUTY booking ${b.id}`, text: fill(`Hi {first},\n\nWe have received your payment of ${naira((b.pay || {}).amount || b.est)} for booking {ref}. Thank you!\n\nDate: {date}\nTime: {time}\n\nSee you soon,\nDYANBEAUTY`, pv) });
    }
    const was = before.get(b.id);
    if (!was || was === b.status || !b.email) continue;
    const v = varsFor({ name: b.name, email: b.email, booking: b });
    if (b.status === 'Confirmed') queueMail({ to: b.email, kind: 'confirmed', subject: `Your DYANBEAUTY appointment is confirmed · ${v.date}`, text: fill('Hi {first},\n\nYour appointment is confirmed!\n\nServices: {services}\nDate: {date}\nTime: {time}\nBooking ref: {ref}\n\nWe can\'t wait to see you.\nDYANBEAUTY', v) });
    if (b.status === 'Cancelled') queueMail({ to: b.email, kind: 'cancelled', subject: `Your DYANBEAUTY booking ${b.id} was cancelled`, text: fill('Hi {first},\n\nYour booking for {date} at {time} has been cancelled. If this is a mistake or you would like a new time, reply to this email or book again on our website.\n\nDYANBEAUTY', v) });
    if (b.status === 'Completed') queueMail({ to: b.email, kind: 'thank-you', subject: 'Thank you for visiting DYANBEAUTY', text: fill('Hi {first},\n\nThank you for your visit today! We hope you love your look.' + (v.card ? '\n\nYour loyalty card {card} now has {points} points.' : '\n\nJoin the DYAN Loyalty Club on our website to earn points on every visit.') + '\n\nTag us on Instagram @dyanbeauty__ so we can see you shine.\n\nDYANBEAUTY', v) });
  }
}

let cronBusy = false;
async function cron() {
  if (cronBusy) return;
  cronBusy = true;
  try {
    dailyBackup();
    const s = mailSettings();
    const now = Date.now();
    // appointment reminders
    if (s.remindOn && mailReady()) {
      const hours = (Array.isArray(s.remindHours) ? s.remindHours : [24]).map(Number).filter((h) => h > 0 && h <= 168).sort((a, b) => b - a);
      for (const d of dlist('bookings')) {
        let changed = false;
        for (const b of (d.items || [])) {
          if (!b.email || !b.date) continue;
          if (!(b.status === 'Confirmed' || (s.remindPending && b.status === 'Pending'))) continue;
          const t = apptTime(b);
          if (t <= now) continue;
          b.reminded = b.reminded || {};
          for (const h of hours) {
            if (b.reminded[h]) continue;
            const windowStart = t - h * 3600e3;
            if (now < windowStart) continue;
            // booked after this reminder time: skip it quietly
            if (b.created && new Date(b.created).getTime() > windowStart) { b.reminded[h] = 'skipped'; changed = true; continue; }
            const v = varsFor({ name: b.name, email: b.email, booking: b });
            queueMail({ to: b.email, kind: `reminder-${h}h`, subject: fill(s.reminderSubject, v), text: fill(s.reminderBody, v) });
            b.reminded[h] = new Date().toISOString();
            changed = true;
          }
        }
        if (changed) { const { _id, ...doc } = d; dset('bookings', _id, doc); }
      }
    }
    // scheduled and repeating mail campaigns
    for (const c of dlist('campaigns')) {
      if (c.status !== 'scheduled' || !c.nextRun || c.nextRun > now) continue;
      const list = resolveAudience(c.audience);
      for (const r of list) {
        const v = varsFor({ name: r.name, email: r.email, booking: r.booking });
        queueMail({ to: r.email, kind: 'campaign', subject: fill(c.subject, v), text: fill(c.body, v) });
      }
      const next = { ...c, lastRun: now, lastCount: list.length, runs: (c.runs || 0) + 1 };
      delete next._id;
      if (c.repeat === 'daily' || c.repeat === 'weekly' || c.repeat === 'monthly') {
        const d = new Date(c.nextRun);
        while (d.getTime() <= now) {
          if (c.repeat === 'daily') d.setDate(d.getDate() + 1);
          else if (c.repeat === 'weekly') d.setDate(d.getDate() + 7);
          else d.setMonth(d.getMonth() + 1);
        }
        next.nextRun = d.getTime();
      } else {
        next.status = 'sent';
      }
      dset('campaigns', c._id, next);
    }
  } catch (e) {
    console.error('Scheduler error:', e);
  } finally {
    cronBusy = false;
  }
}

/* ---------- routes ---------- */
async function api(req, res, url, ctx) {
  const p = url.pathname;
  const m = req.method;
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  const needAdmin = () => { if (!ctx.admin) { send(res, 401, { error: 'admin_only' }); return false; } return true; };

  if (p === '/api/health') return send(res, 200, { ok: true });
  if (p === '/api/me' && m === 'GET') {
    return send(res, 200, { vid: ctx.vid, admin: ctx.admin, mail: { configured: mailReady(), from: ctx.admin ? CFG.gmailUser : undefined, owner: ctx.admin ? CFG.ownerEmail : undefined } });
  }

  if (p === '/api/admin/login' && m === 'POST') {
    if (limited(ip, 'admin')) return send(res, 429, { error: 'too_many_attempts' });
    const { password } = await readJSON(req, 4096);
    if (!ADMIN_HASH) return send(res, 503, { error: 'no_admin_password' });
    if (!passwordOk(password)) return send(res, 401, { error: 'wrong_password' });
    attempts.delete('admin:' + ip);
    setCookie(req, res, 'dy_adm', newAdminSession(), SESSION_DAYS * 86400);
    return send(res, 200, { ok: true });
  }
  if (p === '/api/admin/logout' && m === 'POST') {
    if (ctx.admToken) { delete DB.sessions[sha256(ctx.admToken)]; persist(); }
    setCookie(req, res, 'dy_adm', '', 0);
    return send(res, 200, { ok: true });
  }

  if (p === '/api/member/login' && m === 'POST') {
    if (limited(ip, 'member')) return send(res, 429, { error: 'too_many_attempts' });
    const { email, pinHash } = await readJSON(req, 4096);
    const mem = memberByEmail(email);
    if (!mem || !mem.pinHash || typeof pinHash !== 'string' || mem.pinHash.length !== pinHash.length ||
        !crypto.timingSafeEqual(Buffer.from(mem.pinHash), Buffer.from(pinHash)) || !VID.test(mem._id)) {
      return send(res, 401, { error: 'no_match' });
    }
    carryGuestBookings(ctx.vid, mem._id);
    setCookie(req, res, 'dy_vid', mem._id, 2 * 365 * 86400);
    return send(res, 200, { key: mem._id, mustChange: !!mem.mustChange });
  }
  if (p === '/api/member/pin' && m === 'POST') {
    if (limited(ip, 'member')) return send(res, 429, { error: 'too_many_attempts' });
    const { oldHash, newHash } = await readJSON(req, 4096);
    const mem = dget('members', ctx.vid);
    if (!mem || !mem.pinHash) return send(res, 401, { error: 'Log in to your card first.' });
    if (!sameHash(mem.pinHash, oldHash)) return send(res, 401, { error: 'Your current PIN is not right.' });
    if (!PIN_HASH(newHash)) return send(res, 400, { error: 'Choose a 4 to 6 digit PIN.' });
    mem.pinHash = newHash; delete mem.mustChange; mem.pinChangedAt = new Date().toISOString();
    dset('members', ctx.vid, mem);
    pinEmail(mem, 'changed');
    return send(res, 200, { ok: true });
  }
  if (p === '/api/member/forgot' && m === 'POST') {
    if (limited(ip, 'forgot')) return send(res, 429, { error: 'Too many requests. Try again in 15 minutes.' });
    const { email } = await readJSON(req, 4096);
    const mem = memberByEmail(email);
    if (mem && mem.email) {
      const code = String(crypto.randomInt(100000, 1000000));
      DB.resets[mem.email] = { codeHash: sha256(code), exp: Date.now() + 15 * 60e3, tries: 0 };
      persist();
      queueMail({ to: mem.email, kind: 'pin-reset-code', subject: 'Your DYANBEAUTY PIN reset code: ' + code,
        text: `Hi ${String(mem.name || '').split(' ')[0] || 'there'},\n\nUse this code to set a new PIN for your loyalty card:\n\n${code}\n\nIt works for 15 minutes. If you didn't ask for this, you can ignore this email.\n\nDYANBEAUTY` });
    }
    // same answer either way, so nobody can test which emails have cards
    return send(res, 200, { ok: true, mail: mailReady() });
  }
  if (p === '/api/member/reset' && m === 'POST') {
    const { email, code, newHash } = await readJSON(req, 4096);
    const mem = memberByEmail(email);
    const r = mem && DB.resets[mem.email];
    if (!r || r.exp < Date.now() || r.tries >= 5) return send(res, 400, { error: 'That code has expired. Ask for a new one.' });
    if (!sameHash(r.codeHash, sha256(String(code || '').trim()))) { r.tries++; persist(); return send(res, 400, { error: 'That code is not right. Check the email and try again.' }); }
    if (!PIN_HASH(newHash)) return send(res, 400, { error: 'Choose a 4 to 6 digit PIN.' });
    delete DB.resets[mem.email];
    const doc = dget('members', mem._id);
    doc.pinHash = newHash; delete doc.mustChange; doc.pinChangedAt = new Date().toISOString();
    dset('members', mem._id, doc);
    carryGuestBookings(ctx.vid, mem._id);
    setCookie(req, res, 'dy_vid', mem._id, 2 * 365 * 86400);
    pinEmail(doc, 'reset');
    return send(res, 200, { key: mem._id });
  }
  if (p === '/api/admin/member-pin' && m === 'POST') {
    if (!needAdmin()) return;
    const { id, pin, notify } = await readJSON(req, 4096);
    const doc = SEG.test(String(id || '')) && dget('members', id);
    if (!doc) return send(res, 404, { error: 'Client not found.' });
    if (!doc.email) return send(res, 400, { error: 'This client has no email address, so they cannot log in. Add one first.' });
    if (!/^\d{4,6}$/.test(String(pin || ''))) return send(res, 400, { error: 'A PIN is 4 to 6 digits.' });
    doc.pinHash = sha256(doc.email.toLowerCase() + ':' + pin); doc.mustChange = true; doc.pinChangedAt = new Date().toISOString();
    dset('members', id, doc);
    if (notify) pinEmail(doc, 'reset', pin);
    return send(res, 200, { ok: true, emailed: !!notify && mailReady() });
  }
  if (p === '/api/member/email-change' && m === 'POST') {
    if (limited(ip, 'email-change')) return send(res, 429, { error: 'Too many tries. Wait 15 minutes and try again.' });
    const { newEmail, pinHash, newPinHash } = await readJSON(req, 4096);
    const mem = dget('members', ctx.vid);
    if (!mem || !mem.pinHash) return send(res, 401, { error: 'Log in to your card first.' });
    if (!sameHash(mem.pinHash, pinHash)) return send(res, 401, { error: 'Your PIN is not right.' });
    const ne = String(newEmail || '').trim().toLowerCase();
    if (!EMAIL.test(ne)) return send(res, 400, { error: 'Enter a full email address.' });
    if (ne === mem.email) return send(res, 400, { error: 'That is already the email on your card.' });
    const other = memberByEmail(ne);
    if (other && other._id !== ctx.vid) return send(res, 409, { error: 'Another card already uses that email.' });
    if (!PIN_HASH(newPinHash)) return send(res, 400, { error: 'bad_pin' });
    if (!mailReady()) return send(res, 503, { error: 'Email isn\'t set up on the studio\'s website yet, so we can\'t confirm a new address. Ask the studio to change it for you.' });
    const code = String(crypto.randomInt(100000, 1000000));
    DB.emailChanges[ctx.vid] = { newEmail: ne, newPinHash, codeHash: sha256(code), exp: Date.now() + 30 * 60e3, tries: 0 };
    persist();
    queueMail({ to: ne, kind: 'email-change-code', subject: 'Confirm your new email for DYANBEAUTY: ' + code,
      text: `Hi ${String(mem.name || '').split(' ')[0] || 'there'},\n\nYou asked to use this email address for your DYANBEAUTY loyalty card.\n\nYour confirmation code: ${code}\n\nEnter it on your profile within 30 minutes. If you didn't ask for this, you can ignore this email and nothing will change.\n\nDYANBEAUTY` });
    return send(res, 200, { ok: true });
  }
  if (p === '/api/member/email-confirm' && m === 'POST') {
    const { code } = await readJSON(req, 4096);
    const pend = DB.emailChanges[ctx.vid];
    const mem = dget('members', ctx.vid);
    if (!mem || !pend || pend.exp < Date.now() || pend.tries >= 5) return send(res, 400, { error: 'That code has expired. Start the change again.' });
    if (!sameHash(pend.codeHash, sha256(String(code || '').trim()))) { pend.tries++; persist(); return send(res, 400, { error: 'That code is not right. Check the email and try again.' }); }
    const other = memberByEmail(pend.newEmail);
    if (other && other._id !== ctx.vid) { delete DB.emailChanges[ctx.vid]; persist(); return send(res, 409, { error: 'Another card already uses that email.' }); }
    const oldEmail = mem.email;
    mem.email = pend.newEmail; mem.pinHash = pend.newPinHash; mem.emailChangedAt = new Date().toISOString();
    dset('members', ctx.vid, mem);
    delete DB.emailChanges[ctx.vid]; persist();
    const bk = dget('bookings', ctx.vid);
    if (bk && (bk.items || []).some((x) => x.email === oldEmail)) { bk.items.forEach((x) => { if (x.email === oldEmail) x.email = mem.email; }); dset('bookings', ctx.vid, bk); }
    const first = String(mem.name || '').split(' ')[0] || 'there';
    queueMail({ to: mem.email, kind: 'email-changed', subject: 'Your new email is confirmed', text: `Hi ${first},\n\nThis is now the email for your DYANBEAUTY loyalty card. Log in with it and your usual PIN.\n\nDYANBEAUTY` });
    if (oldEmail) queueMail({ to: oldEmail, kind: 'email-changed-old', subject: 'The email on your DYANBEAUTY card was changed', text: `Hi ${first},\n\nThe email on your DYANBEAUTY loyalty card was changed to ${mem.email}.\n\nIf you didn't do this, reply to this email or call the studio straight away and we'll secure your card.\n\nDYANBEAUTY` });
    return send(res, 200, { ok: true, email: mem.email });
  }
  if (p === '/api/member/logout' && m === 'POST') {
    const vid = rid(18);
    setCookie(req, res, 'dy_vid', vid, 2 * 365 * 86400);
    return send(res, 200, { vid });
  }

  // generic records with access rules
  const dm = p.match(/^\/api\/db\/([^/]+)(?:\/([^/]+))?$/);
  if (dm) {
    const col = dm[1];
    const id = dm[2];
    if (!SEG.test(col) || !KNOWN.has(col) || (id && !SEG.test(id))) return send(res, 404, { error: 'not_found' });
    if (!id) {
      if (m !== 'GET' || !needAdmin()) return;
      return send(res, 200, { items: dlist(col) });
    }
    const self = id === ctx.vid;
    if (m === 'GET') {
      const allowed = ctx.admin || PUBLIC_READ.has(col) || ((SELF_RW.has(col) || SELF_READ.has(col)) && self);
      const doc = allowed ? dget(col, id) : null;
      return doc ? send(res, 200, { data: doc }) : send(res, 404, { error: 'not_found' });
    }
    if (m === 'DELETE') {
      if (!needAdmin()) return;
      ddel(col, id);
      return send(res, 200, { ok: true });
    }
    if (m === 'PUT') {
      const body = await readJSON(req, 300 * 1024);
      if (!body || typeof body !== 'object' || Array.isArray(body)) return send(res, 400, { error: 'bad_body' });
      if (JSON.stringify(body).length > 256 * 1024) return send(res, 413, { error: 'too_large' });
      const prev = dget(col, id);
      if (ctx.admin) {
        dset(col, id, body);
        if (col === 'bookings') onStatusChanges(prev, body);
        return send(res, 200, { ok: true });
      }
      if (!SELF_RW.has(col) || !self) return send(res, 403, { error: 'not_allowed' });
      if (col === 'bookings') {
        const { doc, fresh, reported } = sanitizeBookingsDoc(id, body, prev);
        dset(col, id, doc);
        if (fresh.length) onNewBookings(fresh);
        if (reported.length) onPaymentReported(reported);
        return send(res, 200, { ok: true, received: fresh.map((b) => b.id), mailed: mailReady() });
      }
      if (col === 'members') {
        const doc = sanitizeMemberDoc(id, body, prev);
        dset(col, id, doc);
        if (!(prev && prev.pinHash) && doc.pinHash) onSignup(doc);
        else if (prev && prev.pinHash) detailsEmail(prev, doc);
        return send(res, 200, { ok: true, ref: doc.ref });
      }
      if (col === 'subs') { dset(col, id, sanitizeSub(body)); return send(res, 200, { ok: true }); }
    }
    return send(res, 405, { error: 'method_not_allowed' });
  }

  if (p === '/api/receipt' && m === 'POST') {
    if (limited(ip, 'receipt')) return send(res, 429, { error: 'Too many uploads. Try again later.' });
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' }[type];
    if (!ext) return send(res, 415, { error: 'Upload a photo or screenshot of your receipt.' });
    const buf = await readBody(req, 6 * 1024 * 1024);
    const name = 'r' + Date.now().toString(36) + rid(9) + ext;
    fs.writeFileSync(path.join(RECEIPTS, name), buf);
    return send(res, 200, { name });
  }
  const rm = p.match(/^\/api\/admin\/receipt\/([A-Za-z0-9_.-]+)$/);
  if (rm && m === 'GET') {
    if (!needAdmin()) return;
    if (!RECEIPT_NAME.test(rm[1])) return send(res, 404, { error: 'not_found' });
    return serveFile(res, path.join(RECEIPTS, rm[1]), 'private, no-store');
  }
  if (p === '/api/admin/upload' && m === 'POST') {
    if (!needAdmin()) return;
    const type = String(req.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
    const ext = { 'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp', 'image/gif': '.gif' }[type];
    if (!ext) return send(res, 415, { error: 'Upload a JPG, PNG, WebP or GIF photo.' });
    const buf = await readBody(req, 10 * 1024 * 1024);
    const name = Date.now().toString(36) + '-' + rid(6) + ext;
    fs.writeFileSync(path.join(UPLOADS, name), buf);
    return send(res, 200, { url: '/uploads/' + name, sizeBytes: buf.length });
  }

  if (p === '/api/admin/mail/preview' && m === 'POST') {
    if (!needAdmin()) return;
    const { audience } = await readJSON(req);
    const list = resolveAudience(audience);
    return send(res, 200, { count: list.length, recipients: list.slice(0, 200).map((r) => ({ email: r.email, name: r.name || '', when: r.booking ? `${r.booking.date} ${fmtHour(r.booking.start)}` : '' })) });
  }
  if (p === '/api/admin/mail/send' && m === 'POST') {
    if (!needAdmin()) return;
    const { audience, subject, body, sendAt, repeat, name } = await readJSON(req);
    if (!String(subject || '').trim() || !String(body || '').trim()) return send(res, 400, { error: 'Add a subject and a message.' });
    const when = sendAt ? new Date(sendAt).getTime() : 0;
    const rep = ['daily', 'weekly', 'monthly'].includes(repeat) ? repeat : 'none';
    if ((when && when > Date.now() + 30e3) || rep !== 'none') {
      const id = 'c' + Date.now().toString(36) + rid(3);
      dset('campaigns', id, { name: clip(name || subject, 120), audience: audience || {}, subject: clip(subject, 200), body: clip(body, 20000), repeat: rep, nextRun: when || Date.now(), status: 'scheduled', created: new Date().toISOString(), runs: 0 });
      setTimeout(cron, 1000);
      return send(res, 200, { scheduled: true, id });
    }
    if (!mailReady()) return send(res, 503, { error: 'Gmail is not set up on the server yet. Add GMAIL_USER and GMAIL_APP_PASSWORD to the .env file.' });
    const list = resolveAudience(audience);
    for (const r of list) {
      const v = varsFor({ name: r.name, email: r.email, booking: r.booking });
      queueMail({ to: r.email, kind: 'manual', subject: fill(subject, v), text: fill(body, v) });
    }
    return send(res, 200, { queued: list.length });
  }
  if (p === '/api/admin/mail/test' && m === 'POST') {
    if (!needAdmin()) return;
    if (!mailReady()) return send(res, 503, { error: 'Gmail is not set up on the server yet.' });
    const { to } = await readJSON(req, 4096);
    const target = EMAIL.test(String(to || '')) ? to : CFG.ownerEmail;
    const ok = await queueMail({ to: target, kind: 'test', subject: 'DYANBEAUTY test email', text: 'Hi!\n\nYour DYANBEAUTY website can send email. Booking alerts, reminders and campaigns will arrive like this one.\n\nDYANBEAUTY' });
    const last = (dget('maillog', 'recent') || { items: [] }).items[0];
    return ok ? send(res, 200, { ok: true, to: target }) : send(res, 502, { error: (last && last.error) || 'Sending failed' });
  }

  return send(res, 404, { error: 'not_found' });
}

async function route(req, res) {
  const url = new URL(req.url, 'http://localhost');
  let p;
  try { p = decodeURIComponent(url.pathname); } catch (e) { res.writeHead(400); res.end(); return; }

  const cookies = parseCookies(req);
  let vid = cookies.dy_vid;
  if (!vid || !VID.test(vid)) { vid = rid(18); setCookie(req, res, 'dy_vid', vid, 2 * 365 * 86400); }
  const ctx = { vid, admToken: cookies.dy_adm, admin: isAdminToken(cookies.dy_adm) };

  if (p.startsWith('/api/')) {
    try { await api(req, res, url, ctx); }
    catch (e) { if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'server_error' }); if (!e.status) console.error(e); }
    return;
  }
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); res.end(); return; }
  if (p.startsWith('/uploads/')) {
    const name = path.basename(p);
    if (!/^[A-Za-z0-9_.-]+$/.test(name)) { res.writeHead(404); res.end(); return; }
    return serveFile(res, path.join(UPLOADS, name), 'public, max-age=31536000, immutable');
  }
  const pub = path.join(ROOT, 'public');
  let file = path.normalize(path.join(pub, p === '/' ? 'index.html' : p));
  if (!file.startsWith(pub)) { res.writeHead(404); res.end(); return; }
  if (!path.extname(file)) file = path.join(pub, 'index.html');
  if (p === '/robots.txt' && !fs.existsSync(file)) {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`User-agent: *\nAllow: /\nDisallow: /api/\n${CFG.siteUrl ? `Sitemap: ${CFG.siteUrl}/sitemap.xml\n` : ''}`);
    return;
  }
  if (p === '/sitemap.xml' && CFG.siteUrl) {
    res.writeHead(200, { 'Content-Type': 'application/xml' });
    res.end(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${CFG.siteUrl}/</loc><changefreq>weekly</changefreq><priority>1.0</priority></url></urlset>`);
    return;
  }
  serveFile(res, file, file.endsWith('.html') ? 'no-cache' : 'public, max-age=86400');
}

/* ---------- start ---------- */
const server = http.createServer((req, res) => { route(req, res).catch((e) => { console.error(e); if (!res.headersSent) send(res, 500, { error: 'server_error' }); }); });
if (require.main === module) {
  server.listen(CFG.port, () => {
    console.log(`DYANBEAUTY is running on http://localhost:${CFG.port}`);
    if (!ADMIN_HASH) console.warn('ADMIN_PASSWORD is not set: the admin portal will stay locked.');
    if (!mailReady()) console.warn('Gmail is not set up (GMAIL_USER / GMAIL_APP_PASSWORD): emails will be logged but not sent.');
  });
  setInterval(cron, 60e3);
  setTimeout(cron, 5e3);
  const stop = () => { try { flush(); } catch (e) { /* ignore */ } process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}
module.exports = { server, cron, CFG, buildMessage, smtpSend, resolveAudience, flush };
